﻿namespace GEST_TRIATHLON
{
    partial class FormListeInscription
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Ajouter = new System.Windows.Forms.Button();
            this.btn_Reinitialiser = new System.Windows.Forms.Button();
            this.btn_Filtrer = new System.Windows.Forms.Button();
            this.cb_Triathlon = new System.Windows.Forms.ComboBox();
            this.LabelTriathlon = new System.Windows.Forms.Label();
            this.tb_Nom = new System.Windows.Forms.TextBox();
            this.LabelNom = new System.Windows.Forms.Label();
            this.tb_NumLicence = new System.Windows.Forms.TextBox();
            this.LabelNumLicence = new System.Windows.Forms.Label();
            this.dgv_Liste = new System.Windows.Forms.DataGridView();
            this.cb_Lieu = new System.Windows.Forms.ComboBox();
            this.LabelLieu = new System.Windows.Forms.Label();
            this.dtp_Date = new System.Windows.Forms.DateTimePicker();
            this.Date = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Liste)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_Ajouter
            // 
            this.btn_Ajouter.Location = new System.Drawing.Point(856, 52);
            this.btn_Ajouter.Name = "btn_Ajouter";
            this.btn_Ajouter.Size = new System.Drawing.Size(245, 30);
            this.btn_Ajouter.TabIndex = 34;
            this.btn_Ajouter.Text = "Ajouter une inscription";
            this.btn_Ajouter.UseVisualStyleBackColor = true;
            this.btn_Ajouter.Click += new System.EventHandler(this.btn_Ajouter_Click);
            // 
            // btn_Reinitialiser
            // 
            this.btn_Reinitialiser.Location = new System.Drawing.Point(982, 17);
            this.btn_Reinitialiser.Name = "btn_Reinitialiser";
            this.btn_Reinitialiser.Size = new System.Drawing.Size(119, 25);
            this.btn_Reinitialiser.TabIndex = 33;
            this.btn_Reinitialiser.Text = "Réinitialiser";
            this.btn_Reinitialiser.UseVisualStyleBackColor = true;
            // 
            // btn_Filtrer
            // 
            this.btn_Filtrer.Location = new System.Drawing.Point(856, 17);
            this.btn_Filtrer.Name = "btn_Filtrer";
            this.btn_Filtrer.Size = new System.Drawing.Size(120, 25);
            this.btn_Filtrer.TabIndex = 32;
            this.btn_Filtrer.Text = "Filtrer";
            this.btn_Filtrer.UseVisualStyleBackColor = true;
            // 
            // cb_Triathlon
            // 
            this.cb_Triathlon.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_Triathlon.FormattingEnabled = true;
            this.cb_Triathlon.Location = new System.Drawing.Point(72, 49);
            this.cb_Triathlon.Name = "cb_Triathlon";
            this.cb_Triathlon.Size = new System.Drawing.Size(183, 21);
            this.cb_Triathlon.TabIndex = 31;
            // 
            // LabelTriathlon
            // 
            this.LabelTriathlon.AutoSize = true;
            this.LabelTriathlon.Location = new System.Drawing.Point(12, 52);
            this.LabelTriathlon.Name = "LabelTriathlon";
            this.LabelTriathlon.Size = new System.Drawing.Size(54, 13);
            this.LabelTriathlon.TabIndex = 30;
            this.LabelTriathlon.Text = "Triathlon :";
            // 
            // tb_Nom
            // 
            this.tb_Nom.Location = new System.Drawing.Point(261, 19);
            this.tb_Nom.Name = "tb_Nom";
            this.tb_Nom.Size = new System.Drawing.Size(150, 20);
            this.tb_Nom.TabIndex = 21;
            // 
            // LabelNom
            // 
            this.LabelNom.AutoSize = true;
            this.LabelNom.Location = new System.Drawing.Point(220, 22);
            this.LabelNom.Name = "LabelNom";
            this.LabelNom.Size = new System.Drawing.Size(35, 13);
            this.LabelNom.TabIndex = 20;
            this.LabelNom.Text = "Nom :";
            // 
            // tb_NumLicence
            // 
            this.tb_NumLicence.Location = new System.Drawing.Point(101, 19);
            this.tb_NumLicence.Name = "tb_NumLicence";
            this.tb_NumLicence.Size = new System.Drawing.Size(100, 20);
            this.tb_NumLicence.TabIndex = 19;
            // 
            // LabelNumLicence
            // 
            this.LabelNumLicence.AutoSize = true;
            this.LabelNumLicence.Location = new System.Drawing.Point(12, 22);
            this.LabelNumLicence.Name = "LabelNumLicence";
            this.LabelNumLicence.Size = new System.Drawing.Size(77, 13);
            this.LabelNumLicence.TabIndex = 18;
            this.LabelNumLicence.Text = "N° de licence :";
            // 
            // dgv_Liste
            // 
            this.dgv_Liste.AllowUserToAddRows = false;
            this.dgv_Liste.AllowUserToDeleteRows = false;
            this.dgv_Liste.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_Liste.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgv_Liste.Location = new System.Drawing.Point(12, 105);
            this.dgv_Liste.Name = "dgv_Liste";
            this.dgv_Liste.ReadOnly = true;
            this.dgv_Liste.Size = new System.Drawing.Size(1087, 425);
            this.dgv_Liste.TabIndex = 35;
            // 
            // cb_Lieu
            // 
            this.cb_Lieu.FormattingEnabled = true;
            this.cb_Lieu.Location = new System.Drawing.Point(302, 49);
            this.cb_Lieu.Name = "cb_Lieu";
            this.cb_Lieu.Size = new System.Drawing.Size(121, 21);
            this.cb_Lieu.TabIndex = 37;
            // 
            // LabelLieu
            // 
            this.LabelLieu.AutoSize = true;
            this.LabelLieu.Location = new System.Drawing.Point(261, 52);
            this.LabelLieu.Name = "LabelLieu";
            this.LabelLieu.Size = new System.Drawing.Size(33, 13);
            this.LabelLieu.TabIndex = 36;
            this.LabelLieu.Text = "Lieu :";
            // 
            // dtp_Date
            // 
            this.dtp_Date.Checked = false;
            this.dtp_Date.Location = new System.Drawing.Point(52, 79);
            this.dtp_Date.Name = "dtp_Date";
            this.dtp_Date.ShowCheckBox = true;
            this.dtp_Date.Size = new System.Drawing.Size(255, 20);
            this.dtp_Date.TabIndex = 39;
            // 
            // Date
            // 
            this.Date.AutoSize = true;
            this.Date.Location = new System.Drawing.Point(14, 82);
            this.Date.Name = "Date";
            this.Date.Size = new System.Drawing.Size(30, 13);
            this.Date.TabIndex = 38;
            this.Date.Text = "Date";
            // 
            // FormListeInscription
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1111, 542);
            this.Controls.Add(this.dtp_Date);
            this.Controls.Add(this.Date);
            this.Controls.Add(this.cb_Lieu);
            this.Controls.Add(this.LabelLieu);
            this.Controls.Add(this.dgv_Liste);
            this.Controls.Add(this.btn_Ajouter);
            this.Controls.Add(this.btn_Reinitialiser);
            this.Controls.Add(this.btn_Filtrer);
            this.Controls.Add(this.cb_Triathlon);
            this.Controls.Add(this.LabelTriathlon);
            this.Controls.Add(this.tb_Nom);
            this.Controls.Add(this.LabelNom);
            this.Controls.Add(this.tb_NumLicence);
            this.Controls.Add(this.LabelNumLicence);
            this.Name = "FormListeInscription";
            this.Text = "Liste des Inscriptions ";
            this.Load += new System.EventHandler(this.FormListeInscription_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Liste)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btn_Ajouter;
        private System.Windows.Forms.Button btn_Reinitialiser;
        private System.Windows.Forms.Button btn_Filtrer;
        private System.Windows.Forms.ComboBox cb_Triathlon;
        private System.Windows.Forms.Label LabelTriathlon;
        private System.Windows.Forms.TextBox tb_Nom;
        private System.Windows.Forms.Label LabelNom;
        private System.Windows.Forms.TextBox tb_NumLicence;
        private System.Windows.Forms.Label LabelNumLicence;
        private System.Windows.Forms.DataGridView dgv_Liste;
        private System.Windows.Forms.ComboBox cb_Lieu;
        private System.Windows.Forms.Label LabelLieu;
        private System.Windows.Forms.DateTimePicker dtp_Date;
        private System.Windows.Forms.Label Date;
    }
}