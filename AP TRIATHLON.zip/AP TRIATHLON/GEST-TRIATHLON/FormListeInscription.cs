﻿using BLL;
using DAL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GEST_TRIATHLON
{
    public partial class FormListeInscription : Form
    {
        public FormListeInscription()
        {
            InitializeComponent();

            btn_Filtrer.Click += btn_Filtrer_Click;
            btn_Reinitialiser.Click += btn_Reinitialiser_Click;
        }

        private void FormListeInscription_Load(object sender, EventArgs e)
        {
            ChargerInscriptions();
            RemplirComboBoxes();

            dgv_Liste.CellDoubleClick += dgv_Liste_CellDoubleClick;
        }

        private void ChargerInscriptions()
        {
            var list = InscriptionDAO.GetToutesLesInscriptions();
            AfficherInscriptions(list);
        }

        private void AfficherInscriptions(List<Inscription> list)
        {
            if (list != null)
            {
                dgv_Liste.DataSource = null;
                dgv_Liste.DataSource = list;

                if (dgv_Liste.Columns["IdTriathlon"] != null)
                    dgv_Liste.Columns["IdTriathlon"].Visible = false;

                if (dgv_Liste.Columns["NumLicence"] != null)
                    dgv_Liste.Columns["NumLicence"].HeaderText = "Licence";

                if (dgv_Liste.Columns["NumDossard"] != null)
                    dgv_Liste.Columns["NumDossard"].HeaderText = "Dossard";

                if (dgv_Liste.Columns["DateInscription"] != null)
                {
                    dgv_Liste.Columns["DateInscription"].HeaderText = "Date inscription";
                    dgv_Liste.Columns["DateInscription"].DefaultCellStyle.Format = "dd/MM/yyyy";
                }

                if (dgv_Liste.Columns["Forfait"] != null)
                    dgv_Liste.Columns["Forfait"].HeaderText = "Forfait";

                if (dgv_Liste.Columns["NomTriathlon"] != null)
                    dgv_Liste.Columns["NomTriathlon"].HeaderText = "Triathlon";

                if (dgv_Liste.Columns["DateTriathlon"] != null)
                {
                    dgv_Liste.Columns["DateTriathlon"].HeaderText = "Date triathlon";
                    dgv_Liste.Columns["DateTriathlon"].DefaultCellStyle.Format = "dd/MM/yyyy";
                }

                if (dgv_Liste.Columns["LieuTriathlon"] != null)
                    dgv_Liste.Columns["LieuTriathlon"].HeaderText = "Lieu";

                dgv_Liste.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

                dgv_Liste.Columns["NumLicence"].DisplayIndex = 0;
                dgv_Liste.Columns["NomTriathlete"].DisplayIndex = 1;
                dgv_Liste.Columns["PrenomTriathlete"].DisplayIndex = 2;
                dgv_Liste.Columns["NumDossard"].DisplayIndex = 3;
                dgv_Liste.Columns["DateInscription"].DisplayIndex = 4;
                dgv_Liste.Columns["Forfait"].DisplayIndex = 5;
                dgv_Liste.Columns["NomTriathlon"].DisplayIndex = 6;
                dgv_Liste.Columns["DateTriathlon"].DisplayIndex = 7;
                dgv_Liste.Columns["LieuTriathlon"].DisplayIndex = 8;

                dgv_Liste.Columns["NomTriathlete"].HeaderText = "Nom";
                dgv_Liste.Columns["PrenomTriathlete"].HeaderText = "Prénom";
                dgv_Liste.Columns["NomTriathlon"].HeaderText = "Triathlon";
                dgv_Liste.Columns["LieuTriathlon"].HeaderText = "Lieu";
            }
            else
            {
                MessageBox.Show("Erreur lors de la récupération des inscriptions");
            }
        }

        private void btn_Filtrer_Click(object sender, EventArgs e)
        {
            int? idTriathlon = null;

            if (cb_Triathlon.SelectedValue != null &&
                int.TryParse(cb_Triathlon.SelectedValue.ToString(), out int id) &&
                id != 0)
            {
                idTriathlon = id;
            }

            string lieu = null;

            if (cb_Lieu.SelectedItem != null)
            {
                lieu = cb_Lieu.SelectedItem.ToString().Trim();

                if (lieu == "")
                    lieu = null;
            }


            string nom = !string.IsNullOrWhiteSpace(tb_Nom.Text) ? tb_Nom.Text.Trim() : null;

            int? numLicence = null;
            if (int.TryParse(tb_NumLicence.Text, out int licence))
                numLicence = licence;

            DateTime? date = dtp_Date.Checked ? dtp_Date.Value.Date : (DateTime?)null;

            var list = InscriptionDAO.GetInscriptionsFiltrees(idTriathlon, lieu, nom, numLicence, date);

            AfficherInscriptions(list);
        }

        private void btn_Reinitialiser_Click(object sender, EventArgs e)
        {
            cb_Triathlon.SelectedIndex = 0;
            cb_Lieu.SelectedIndex = -1;

            tb_Nom.Clear();
            tb_NumLicence.Clear();

            dtp_Date.Checked = false;

            ChargerInscriptions();
        }

        private void RemplirComboBoxes()
        {
            var triathlons = TriathlonDAO.GetLesTriathlons();
            triathlons.Insert(0, new Triathlon { IdTriathlon = 0, NomTriathlon = "" });

            cb_Triathlon.DataSource = triathlons;
            cb_Triathlon.DisplayMember = "NomTriathlon";
            cb_Triathlon.ValueMember = "IdTriathlon";

            var lieux = InscriptionDAO.GetTousLesLieux();
            lieux.Insert(0, ""); 

            cb_Lieu.DataSource = lieux;
        }

        private void btn_Ajouter_Click(object sender, EventArgs e)
        {
            FormAjouterModifierInscription frm = new FormAjouterModifierInscription ();
            frm.ModeAjout();

            if (frm.ShowDialog() == DialogResult.OK)
            {
                ChargerInscriptions();
            }
        }

        private void dgv_Liste_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            Inscription i = (Inscription)dgv_Liste.Rows[e.RowIndex].DataBoundItem;

            FormAjouterModifierInscription f = new FormAjouterModifierInscription();
            f.ModeModification(i);

            if (f.ShowDialog() == DialogResult.OK)
            {
                ChargerInscriptions();
            }
        }
    }
}
